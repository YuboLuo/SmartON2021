SpotON_V4.0:
  I added FFT function. Now we can use FFT to distingusih different sound sources, which can be used as multiple event-types.
  For example, before we introduce FFT, we can only distinguish bwteen having-event and no-event. Now, we can distinguish event1, event2, event3, etc.
  We can assign different reward values to different events. 
  
  Files added from FFT:
  FFT.c
  FFT.h
  FFT_430.asm
  FFT_430.h
  FFT_430.s43
  benchmark.c
  benchmark.h
  
  
