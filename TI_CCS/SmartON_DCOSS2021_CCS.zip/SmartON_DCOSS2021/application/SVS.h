/*
 * SVS.h
 *
 *  Created on: May 13, 2019
 *      Author: Yubo-ASUS
 */

#ifndef SVS_H_
#define SVS_H_


void SW_AddNew(void);

extern uint16_t SupplyVoltage;

void initTimerB_SupplyVoltage(uint8_t);

#endif /* SVS_H_ */
